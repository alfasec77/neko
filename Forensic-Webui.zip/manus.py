Text file: manus.py
Latest content with line numbers:
2	
3	from pydantic import Field, model_validator
4	
5	from app.agent.browser import BrowserContextHelper
6	from app.agent.toolcall import ToolCallAgent
7	from app.config import config
8	from app.logger import logger
9	from app.prompt.manus import NEXT_STEP_PROMPT, SYSTEM_PROMPT
10	from app.tool import Terminate, ToolCollection
11	from app.tool.ask_human import AskHuman
12	from app.tool.browser_use_tool import BrowserUseTool
13	from app.tool.mcp import MCPClients, MCPClientTool
14	from app.tool.python_execute import PythonExecute
15	from app.tool.str_replace_editor import StrReplaceEditor
16	
17	
18	class Manus(ToolCallAgent):
19	    """A versatile general-purpose agent with support for both local and MCP tools."""
20	
21	    name: str = "Manus"
22	    description: str = "A versatile agent that can solve various tasks using multiple tools including MCP-based tools"
23	
24	    system_prompt: str = SYSTEM_PROMPT.format(directory=config.workspace_root)
25	    next_step_prompt: str = NEXT_STEP_PROMPT
26	
27	    max_observe: int = 10000
28	    max_steps: int = 20
29	
30	    # MCP clients for remote tool access
31	    mcp_clients: MCPClients = Field(default_factory=MCPClients)
32	
33	    # Add general-purpose tools to the tool collection
34	    available_tools: ToolCollection = Field(
35	        default_factory=lambda: ToolCollection(
36	            PythonExecute(),
37	            BrowserUseTool(),
38	            StrReplaceEditor(),
39	            AskHuman(),
40	            Terminate(),
41	        )
42	    )
43	
44	    special_tool_names: list[str] = Field(default_factory=lambda: [Terminate().name])
45	    browser_context_helper: Optional[BrowserContextHelper] = None
46	
47	    # Track connected MCP servers
48	    connected_servers: Dict[str, str] = Field(
49	        default_factory=dict
50	    )  # server_id -> url/command