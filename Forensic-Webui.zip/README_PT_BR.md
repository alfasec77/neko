# Interface Web OpenManus

Uma interface web moderna e intuitiva para o agente autônomo OpenManus, desenvolvida com React, FastAPI, tRPC e Tailwind CSS. A interface oferece um chat interativo estilo Grok com suporte completo para gerenciamento de conversas, histórico de mensagens e integração com os agentes e ferramentas do OpenManus.

## Características Principais

- **Interface de Chat Moderna**: Design estilo Grok com tema escuro profissional
- **Gerenciamento de Conversas**: Criar, listar, atualizar e deletar conversas
- **Histórico de Mensagens**: Armazenamento persistente de todas as mensagens
- **Autenticação Segura**: Integração com Manus OAuth
- **Banco de Dados**: MySQL com Drizzle ORM para gerenciamento de dados
- **API tRPC**: Type-safe RPC para comunicação cliente-servidor
- **Responsivo**: Interface adaptável para diferentes tamanhos de tela
- **Português Brasileiro**: Toda a interface em português

## Requisitos

- Node.js 18+
- pnpm (gerenciador de pacotes)
- MySQL 8.0+
- Python 3.10+ (para integração com OpenManus)

## Instalação

### 1. Clonar o Repositório

```bash
git clone https://github.com/seu-usuario/openmanus_web_ui.git
cd openmanus_web_ui
```

### 2. Instalar Dependências

```bash
pnpm install
```

### 3. Configurar Variáveis de Ambiente

Crie um arquivo `.env.local` na raiz do projeto:

```env
# Banco de Dados
DATABASE_URL="mysql://usuario:senha@localhost:3306/openmanus_web_ui"

# JWT
JWT_SECRET="sua-chave-secreta-aqui"

# OAuth Manus
VITE_APP_ID="seu-app-id"
OAUTH_SERVER_URL="https://api.manus.im"
VITE_OAUTH_PORTAL_URL="https://portal.manus.im"

# Informações do Proprietário
OWNER_OPEN_ID="seu-open-id"
OWNER_NAME="Seu Nome"

# APIs Internas
BUILT_IN_FORGE_API_URL="https://api.manus.im"
BUILT_IN_FORGE_API_KEY="sua-chave-api"

# Branding
VITE_APP_TITLE="OpenManus"
VITE_APP_LOGO="https://seu-logo.png"

# Analytics (opcional)
VITE_ANALYTICS_ENDPOINT="https://analytics.seu-dominio.com"
VITE_ANALYTICS_WEBSITE_ID="seu-website-id"
```

### 4. Configurar Banco de Dados

```bash
# Gerar e aplicar migrações
pnpm db:push

# (Opcional) Visualizar banco de dados
pnpm db:studio
```

### 5. Iniciar o Servidor de Desenvolvimento

```bash
pnpm dev
```

O servidor estará disponível em `http://localhost:3000`

## Estrutura do Projeto

```
openmanus_web_ui/
├── client/                    # Frontend React
│   ├── src/
│   │   ├── pages/            # Páginas da aplicação
│   │   ├── components/       # Componentes reutilizáveis
│   │   ├── hooks/            # Custom hooks
│   │   ├── lib/              # Utilitários e configurações
│   │   └── App.tsx           # Componente raiz
│   └── public/               # Arquivos estáticos
├── server/                    # Backend Express/tRPC
│   ├── routers.ts            # Definição das rotas tRPC
│   ├── db.ts                 # Helpers do banco de dados
│   ├── openmanus_integration.py  # Integração com OpenManus
│   └── _core/                # Configurações principais
├── drizzle/                   # Migrações e schema do banco
│   ├── schema.ts             # Definição das tabelas
│   └── migrations/           # Arquivos de migração
├── shared/                    # Código compartilhado
└── storage/                   # Helpers de armazenamento S3
```

## Uso

### Criar uma Nova Conversa

1. Clique no botão "Nova Conversa" na sidebar
2. Digite sua mensagem na área de entrada
3. Pressione Enter ou clique no botão de envio

### Gerenciar Conversas

- **Selecionar Conversa**: Clique em qualquer conversa na sidebar para carregá-la
- **Deletar Conversa**: (Funcionalidade a ser implementada)
- **Arquivar Conversa**: (Funcionalidade a ser implementada)

### Configurações

Acesse as configurações para:
- Alterar tema (claro/escuro)
- Selecionar idioma
- Configurar modelo de IA
- Ajustar temperatura e max tokens
- Ativar/desativar ferramentas

## API tRPC

### Routers Disponíveis

#### `conversations`

- `list`: Listar todas as conversas do usuário
- `create`: Criar uma nova conversa
- `get`: Obter uma conversa específica
- `update`: Atualizar uma conversa
- `delete`: Deletar uma conversa

#### `messages`

- `list`: Listar mensagens de uma conversa
- `send`: Enviar uma mensagem
- `get`: Obter uma mensagem específica

#### `tools`

- `list`: Listar ferramentas disponíveis
- `get`: Obter uma ferramenta específica

#### `preferences`

- `get`: Obter preferências do usuário
- `update`: Atualizar preferências

#### `auth`

- `me`: Obter dados do usuário autenticado
- `logout`: Fazer logout

## Integração com OpenManus

A interface está preparada para integração com o agente OpenManus. Para ativar a integração completa:

1. Configure o caminho do OpenManus em `server/openmanus_integration.py`
2. Implemente o processamento de mensagens no router `messages.send`
3. Configure as ferramentas disponíveis no banco de dados

## Testes

### Executar Testes Unitários

```bash
pnpm vitest
```

### Executar Testes com Cobertura

```bash
pnpm vitest --coverage
```

### Executar Testes de UI

```bash
pnpm test:ui
```

## Build para Produção

```bash
# Build do cliente
pnpm build

# Iniciar servidor de produção
pnpm start
```

## Troubleshooting

### Erro: "Port 3000 is busy"

O servidor usará automaticamente a próxima porta disponível (3001, 3002, etc.)

### Erro: "Database connection failed"

Verifique se:
- MySQL está rodando
- A string `DATABASE_URL` está correta
- O banco de dados foi criado

### Erro: "OAuth initialization failed"

Verifique se:
- `VITE_APP_ID` está configurado corretamente
- `OAUTH_SERVER_URL` está acessível
- As credenciais OAuth são válidas

## Contribuindo

1. Faça um fork do projeto
2. Crie uma branch para sua feature (`git checkout -b feature/AmazingFeature`)
3. Commit suas mudanças (`git commit -m 'Add some AmazingFeature'`)
4. Push para a branch (`git push origin feature/AmazingFeature`)
5. Abra um Pull Request

## Licença

Este projeto está licenciado sob a Licença MIT - veja o arquivo LICENSE para detalhes.

## Suporte

Para suporte, abra uma issue no repositório GitHub ou entre em contato através do email: suporte@openmanus.dev

## Roadmap

- [ ] Integração completa com agente OpenManus
- [ ] Suporte a anexos de arquivos
- [ ] Suporte a markdown nas mensagens
- [ ] Indicador de digitação em tempo real
- [ ] Busca em conversas
- [ ] Compartilhamento de conversas
- [ ] Modo colaborativo
- [ ] Integração com MCP (Model Context Protocol)
- [ ] Suporte a múltiplos idiomas
- [ ] Temas personalizáveis

## Changelog

### v1.0.0 (2025-12-05)

- Lançamento inicial
- Interface de chat funcional
- Gerenciamento de conversas
- Autenticação com Manus OAuth
- Banco de dados com Drizzle ORM
- API tRPC type-safe
- Testes unitários

---

Desenvolvido com ❤️ para a comunidade OpenManus
