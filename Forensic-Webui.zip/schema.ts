import { mysqlEnum, mysqlTable, text, timestamp, varchar, int, boolean } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  id: varchar("id", { length: 64 }).primaryKey(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Conversations table para armazenar histórico de chats
 */
export const conversations = mysqlTable("conversations", {
  id: varchar("id", { length: 64 }).primaryKey(),
  userId: varchar("userId", { length: 64 }).notNull(),
  title: text("title"),
  description: text("description"),
  model: varchar("model", { length: 255 }).default("openmanus-agent"),
  temperature: int("temperature").default(7),
  maxTokens: int("maxTokens").default(4096),
  systemPrompt: text("systemPrompt"),
  isArchived: boolean("isArchived").default(false),
  createdAt: timestamp("createdAt").defaultNow(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow(),
});

export type Conversation = typeof conversations.$inferSelect;
export type InsertConversation = typeof conversations.$inferInsert;

/**
 * Messages table para armazenar mensagens individuais
 */
export const messages = mysqlTable("messages", {
  id: varchar("id", { length: 64 }).primaryKey(),
  conversationId: varchar("conversationId", { length: 64 }).notNull(),
  role: mysqlEnum("role", ["user", "assistant", "system"]).notNull(),
  content: text("content").notNull(),
  toolCalls: text("toolCalls"),
  toolResults: text("toolResults"),
  metadata: text("metadata"),
  createdAt: timestamp("createdAt").defaultNow(),
});

export type Message = typeof messages.$inferSelect;
export type InsertMessage = typeof messages.$inferInsert;

/**
 * Tools/Agents registry
 */
export const tools = mysqlTable("tools", {
  id: varchar("id", { length: 64 }).primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description"),
  category: varchar("category", { length: 64 }),
  isEnabled: boolean("isEnabled").default(true),
  parameters: text("parameters"),
  createdAt: timestamp("createdAt").defaultNow(),
});

export type Tool = typeof tools.$inferSelect;
export type InsertTool = typeof tools.$inferInsert;

/**
 * User preferences
 */
export const userPreferences = mysqlTable("userPreferences", {
  userId: varchar("userId", { length: 64 }).primaryKey(),
  theme: varchar("theme", { length: 64 }).default("light"),
  language: varchar("language", { length: 64 }).default("pt-BR"),
  defaultModel: varchar("defaultModel", { length: 255 }).default("openmanus-agent"),
  defaultTemperature: int("defaultTemperature").default(7),
  defaultMaxTokens: int("defaultMaxTokens").default(4096),
  enabledTools: text("enabledTools"),
  createdAt: timestamp("createdAt").defaultNow(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow(),
});

export type UserPreference = typeof userPreferences.$inferSelect;
export type InsertUserPreference = typeof userPreferences.$inferInsert;
