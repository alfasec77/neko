Text file: main.py
Latest content with line numbers:
1	import argparse
2	import asyncio
3	
4	from app.agent.manus import Manus
5	from app.logger import logger
6	
7	
8	async def main():
9	    # Parse command line arguments
10	    parser = argparse.ArgumentParser(description="Run Manus agent with a prompt")
11	    parser.add_argument(
12	        "--prompt", type=str, required=False, help="Input prompt for the agent"
13	    )
14	    args = parser.parse_args()
15	
16	    # Create and initialize Manus agent
17	    agent = await Manus.create()
18	    try:
19	        # Use command line prompt if provided, otherwise ask for input
20	        prompt = args.prompt if args.prompt else input("Enter your prompt: ")
21	        if not prompt.strip():
22	            logger.warning("Empty prompt provided.")
23	            return
24	
25	        logger.warning("Processing your request...")
26	        await agent.run(prompt)
27	        logger.info("Request processing completed.")
28	    except KeyboardInterrupt:
29	        logger.warning("Operation interrupted.")
30	    finally:
31	        # Ensure agent resources are cleaned up before exiting
32	        await agent.cleanup()
33	
34	
35	if __name__ == "__main__":
36	    asyncio.run(main())
37	