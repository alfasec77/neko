Text file: README.md
Latest content with line numbers:
1	<p align="center">
2	  <img src="assets/logo.jpg" width="200"/>
3	</p>
4	
5	English | [中文](README_zh.md) | [한국어](README_ko.md) | [日本語](README_ja.md)
6	
7	[![GitHub stars](https://img.shields.io/github/stars/FoundationAgents/OpenManus?style=social)](https://github.com/FoundationAgents/OpenManus/stargazers)
8	&ensp;
9	[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT) &ensp;
10	[![Discord Follow](https://dcbadge.vercel.app/api/server/DYn29wFk9z?style=flat)](https://discord.gg/DYn29wFk9z)
11	[![Demo](https://img.shields.io/badge/Demo-Hugging%20Face-yellow)](https://huggingface.co/spaces/lyh-917/OpenManusDemo)
12	[![DOI](https://zenodo.org/badge/DOI/10.5281/zenodo.15186407.svg)](https://doi.org/10.5281/zenodo.15186407)
13	
14	# 👋 OpenManus
15	
16	Manus is incredible, but OpenManus can achieve any idea without an *Invite Code* 🛫!
17	
18	Our team members [@Xinbin Liang](https://github.com/mannaandpoem) and [@Jinyu Xiang](https://github.com/XiangJinyu) (core authors), along with [@Zhaoyang Yu](https://github.com/MoshiQAQ), [@Jiayi Zhang](https://github.com/didiforgithub), and [@Sirui Hong](https://github.com/stellaHSR), we are from [@MetaGPT](https://github.com/geekan/MetaGPT). The prototype is launched within 3 hours and we are keeping building!
19	
20	It's a simple implementation, so we welcome any suggestions, contributions, and feedback!
21	
22	Enjoy your own agent with OpenManus!
23	
24	We're also excited to introduce [OpenManus-RL](https://github.com/OpenManus/OpenManus-RL), an open-source project dedicated to reinforcement learning (RL)- based (such as GRPO) tuning methods for LLM agents, developed collaboratively by researchers from UIUC and OpenManus.
25	
26	## Project Demo
27	
28	<video src="https://private-user-images.githubusercontent.com/61239030/420168772-6dcfd0d2-9142-45d9-b74e-d10aa75073c6.mp4?jwt=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJnaXRodWIuY29tIiwiYXVkIjoicmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSIsImtleSI6ImtleTUiLCJleHAiOjE3NDEzMTgwNTksIm5iZiI6MTc0MTMxNzc1OSwicGF0aCI6Ii82MTIzOTAzMC80MjAxNjg3NzItNmRjZmQwZDItOTE0Mi00NWQ5LWI3NGUtZDEwYWE3NTA3M2M2Lm1wND9YLUFtei1BbGdvcml0aG09QVdTNC1ITUFDLVNIQTI1NiZYLUFtei1DcmVkZW50aWFsPUFLSUFWQ09EWUxTQTUzUFFLNFpBJTJGMjAyNTAzMDclMkZ1cy1lYXN0LTElMkZzMyUyRmF3czRfcmVxdWVzdCZYLUFtei1EYXRlPTIwMjUwMzA3VDAzMjIzOVomWC1BbXotRXhwaXJlcz0zMDAmWC1BbXotU2lnbmF0dXJlPTdiZjFkNjlmYWNjMmEzOTliM2Y3M2VlYjgyNDRlZDJmOWE3NWZhZjE1MzhiZWY4YmQ3NjdkNTYwYTU5ZDA2MzYmWC1BbXotU2lnbmVkSGVhZGVycz1ob3N0In0.UuHQCgWYkh0OQq9qsUWqGsUbhG3i9jcZDAMeHjLt5T4" data-canonical-src="https://private-user-images.githubusercontent.com/61239030/420168772-6dcfd0d2-9142-45d9-b74e-d10aa75073c6.mp4?jwt=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJnaXRodWIuY29tIiwiYXVkIjoicmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSIsImtleSI6ImtleTUiLCJleHAiOjE3NDEzMTgwNTksIm5iZiI6MTc0MTMxNzc1OSwicGF0aCI6Ii82MTIzOTAzMC80MjAxNjg3NzItNmRjZmQwZDItOTE0Mi00NWQ5LWI3NGUtZDEwYWE3NTA3M2M2Lm1wND9YLUFtei1BbGdvcml0aG09QVdTNC1ITUFDLVNIQTI1NiZYLUFtei1DcmVkZW50aWFsPUFLSUFWQ09EWUxTQTUzUFFLNFpBJTJGMjAyNTAzMDclMkZ1cy1lYXN0LTElMkZzMyUyRmF3czRfcmVxdWVzdCZYLUFtei1EYXRlPTIwMjUwMzA3VDAzMjIzOVomWC1BbXotRXhwaXJlcz0zMDAmWC1BbXotU2lnbmF0dXJlPTdiZjFkNjlmYWNjMmEzOTliM2Y3M2VlYjgyNDRlZDJmOWE3NWZhZjE1MzhiZWY4YmQ3NjdkNTYwYTU5ZDA2MzYmWC1BbXotU2lnbmVkSGVhZGVycz1ob3N0In0.UuHQCgWYkh0OQq9qsUWqGsUbhG3i9jcZDAMeHjLt5T4" controls="controls" muted="muted" class="d-block rounded-bottom-2 border-top width-fit" style="max-height:640px; min-height: 200px"></video>
29	
30	## Installation
31	
32	We provide two installation methods. Method 2 (using uv) is recommended for faster installation and better dependency management.
33	
34	### Method 1: Using conda
35	
36	1. Create a new conda environment:
37	
38	```bash
39	conda create -n open_manus python=3.12
40	conda activate open_manus
41	```
42	
43	2. Clone the repository:
44	
45	```bash
46	git clone https://github.com/FoundationAgents/OpenManus.git
47	cd OpenManus
48	```
49	
50	3. Install dependencies:
51	
52	```bash
53	pip install -r requirements.txt
54	```
55	
56	### Method 2: Using uv (Recommended)
57	
58	1. Install uv (A fast Python package installer and resolver):
59	
60	```bash
61	curl -LsSf https://astral.sh/uv/install.sh | sh
62	```
63	
64	2. Clone the repository:
65	
66	```bash
67	git clone https://github.com/FoundationAgents/OpenManus.git
68	cd OpenManus
69	```
70	
71	3. Create a new virtual environment and activate it:
72	
73	```bash
74	uv venv --python 3.12
75	source .venv/bin/activate  # On Unix/macOS
76	# Or on Windows:
77	# .venv\Scripts\activate
78	```
79	
80	4. Install dependencies:
81	
82	```bash
83	uv pip install -r requirements.txt
84	```
85	
86	### Browser Automation Tool (Optional)
87	```bash
88	playwright install
89	```
90	
91	## Configuration
92	
93	OpenManus requires configuration for the LLM APIs it uses. Follow these steps to set up your configuration:
94	
95	1. Create a `config.toml` file in the `config` directory (you can copy from the example):
96	
97	```bash
98	cp config/config.example.toml config/config.toml
99	```
100	
101	2. Edit `config/config.toml` to add your API keys and customize settings:
102	
103	```toml
104	# Global LLM configuration
105	[llm]
106	model = "gpt-4o"
107	base_url = "https://api.openai.com/v1"
108	api_key = "sk-..."  # Replace with your actual API key
109	max_tokens = 4096
110	temperature = 0.0
111	
112	# Optional configuration for specific LLM models
113	[llm.vision]
114	model = "gpt-4o"
115	base_url = "https://api.openai.com/v1"
116	api_key = "sk-..."  # Replace with your actual API key
117	```
118	
119	## Quick Start
120	
121	One line for run OpenManus:
122	
123	```bash
124	python main.py
125	```
126	
127	Then input your idea via terminal!
128	
129	For MCP tool version, you can run:
130	```bash
131	python run_mcp.py
132	```
133	
134	For unstable multi-agent version, you also can run:
135	
136	```bash
137	python run_flow.py
138	```
139	
140	### Custom Adding Multiple Agents
141	
142	Currently, besides the general OpenManus Agent, we have also integrated the DataAnalysis Agent, which is suitable for data analysis and data visualization tasks. You can add this agent to `run_flow` in `config.toml`.
143	
144	```toml
145	# Optional configuration for run-flow
146	[runflow]
147	use_data_analysis_agent = true     # Disabled by default, change to true to activate
148	```
149	In addition, you need to install the relevant dependencies to ensure the agent runs properly: [Detailed Installation Guide](app/tool/chart_visualization/README.md##Installation)
150	
151	## How to contribute
152	
153	We welcome any friendly suggestions and helpful contributions! Just create issues or submit pull requests.
154	
155	Or contact @mannaandpoem via 📧email: mannaandpoem@gmail.com
156	
157	**Note**: Before submitting a pull request, please use the pre-commit tool to check your changes. Run `pre-commit run --all-files` to execute the checks.
158	
159	## Community Group
160	Join our networking group on Feishu and share your experience with other developers!
161	
162	<div align="center" style="display: flex; gap: 20px;">
163	    <img src="assets/community_group.jpg" alt="OpenManus 交流群" width="300" />
164	</div>
165	
166	## Star History
167	
168	[![Star History Chart](https://api.star-history.com/svg?repos=FoundationAgents/OpenManus&type=Date)](https://star-history.com/#FoundationAgents/OpenManus&Date)
169	
170	## Sponsors
171	Thanks to [PPIO](https://ppinfra.com/user/register?invited_by=OCPKCN&utm_source=github_openmanus&utm_medium=github_readme&utm_campaign=link) for computing source support.
172	> PPIO: The most affordable and easily-integrated MaaS and GPU cloud solution.
173	
174	
175	## Acknowledgement
176	
177	Thanks to [anthropic-computer-use](https://github.com/anthropics/anthropic-quickstarts/tree/main/computer-use-demo), [browser-use](https://github.com/browser-use/browser-use) and [crawl4ai](https://github.com/unclecode/crawl4ai) for providing basic support for this project!
178	
179	Additionally, we are grateful to [AAAJ](https://github.com/metauto-ai/agent-as-a-judge), [MetaGPT](https://github.com/geekan/MetaGPT), [OpenHands](https://github.com/All-Hands-AI/OpenHands) and [SWE-agent](https://github.com/SWE-agent/SWE-agent).
180	
181	We also thank stepfun(阶跃星辰) for supporting our Hugging Face demo space.
182	
183	OpenManus is built by contributors from MetaGPT. Huge thanks to this agent community!
184	
185	## Cite
186	```bibtex
187	@misc{openmanus2025,
188	  author = {Xinbin Liang and Jinyu Xiang and Zhaoyang Yu and Jiayi Zhang and Sirui Hong and Sheng Fan and Xiao Tang},
189	  title = {OpenManus: An open-source framework for building general AI agents},
190	  year = {2025},
191	  publisher = {Zenodo},
192	  doi = {10.5281/zenodo.15186407},
193	  url = {https://doi.org/10.5281/zenodo.15186407},
194	}
195	```
196	