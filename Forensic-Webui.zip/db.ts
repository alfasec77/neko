import { eq, and, desc, isNull } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { 
  InsertUser, 
  users, 
  conversations, 
  messages, 
  tools,
  userPreferences,
  Conversation,
  Message,
  Tool,
  UserPreference
} from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.id) {
    throw new Error("User ID is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      id: user.id,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role === undefined) {
      if (user.id === ENV.ownerId) {
        user.role = 'admin';
        values.role = 'admin';
        updateSet.role = 'admin';
      }
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUser(id: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.id, id)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// ============= Conversation Helpers =============

export async function createConversation(
  userId: string,
  data: Omit<typeof conversations.$inferInsert, 'id' | 'userId' | 'createdAt' | 'updatedAt'>
): Promise<Conversation> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const id = `conv_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  
  await db.insert(conversations).values({
    id,
    userId,
    ...data,
  });

  const result = await db.select().from(conversations).where(eq(conversations.id, id)).limit(1);
  if (!result.length) throw new Error("Failed to create conversation");
  
  return result[0];
}

export async function getConversation(id: string): Promise<Conversation | undefined> {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(conversations).where(eq(conversations.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getUserConversations(userId: string): Promise<Conversation[]> {
  const db = await getDb();
  if (!db) return [];

  return db
    .select()
    .from(conversations)
    .where(and(eq(conversations.userId, userId), isNull(conversations.isArchived)))
    .orderBy(desc(conversations.updatedAt));
}

export async function updateConversation(
  id: string,
  data: Partial<Omit<typeof conversations.$inferInsert, 'id' | 'userId' | 'createdAt'>>
): Promise<Conversation | undefined> {
  const db = await getDb();
  if (!db) return undefined;

  await db.update(conversations).set(data).where(eq(conversations.id, id));
  return getConversation(id);
}

export async function deleteConversation(id: string): Promise<void> {
  const db = await getDb();
  if (!db) return;

  await db.delete(conversations).where(eq(conversations.id, id));
}

// ============= Message Helpers =============

export async function createMessage(
  conversationId: string,
  data: Omit<typeof messages.$inferInsert, 'id' | 'createdAt' | 'conversationId'>
): Promise<Message> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const id = `msg_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  
  await db.insert(messages).values({
    id,
    conversationId,
    ...data,
  });

  const result = await db.select().from(messages).where(eq(messages.id, id)).limit(1);
  if (!result.length) throw new Error("Failed to create message");
  
  return result[0];
}

export async function getConversationMessages(conversationId: string): Promise<Message[]> {
  const db = await getDb();
  if (!db) return [];

  return db
    .select()
    .from(messages)
    .where(eq(messages.conversationId, conversationId))
    .orderBy(messages.createdAt);
}

export async function getMessage(id: string): Promise<Message | undefined> {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(messages).where(eq(messages.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

// ============= Tools Helpers =============

export async function getTools(): Promise<Tool[]> {
  const db = await getDb();
  if (!db) return [];

  return db.select().from(tools).where(eq(tools.isEnabled, true));
}

export async function getTool(id: string): Promise<Tool | undefined> {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(tools).where(eq(tools.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

// ============= User Preferences Helpers =============

export async function getUserPreferences(userId: string): Promise<UserPreference | undefined> {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db
    .select()
    .from(userPreferences)
    .where(eq(userPreferences.userId, userId))
    .limit(1);
  
  return result.length > 0 ? result[0] : undefined;
}

export async function upsertUserPreferences(
  userId: string,
  data: Omit<typeof userPreferences.$inferInsert, 'userId' | 'createdAt' | 'updatedAt'>
): Promise<UserPreference> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db
    .insert(userPreferences)
    .values({ userId, ...data })
    .onDuplicateKeyUpdate({
      set: data,
    });

  const result = await db
    .select()
    .from(userPreferences)
    .where(eq(userPreferences.userId, userId))
    .limit(1);
  
  if (!result.length) throw new Error("Failed to upsert user preferences");
  return result[0];
}
