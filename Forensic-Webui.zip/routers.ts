import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import {
  createConversation,
  getConversation,
  getUserConversations,
  updateConversation,
  deleteConversation,
  createMessage,
  getConversationMessages,
  getMessage,
  getTools,
  getUserPreferences,
  upsertUserPreferences,
} from "./db";
import { z } from "zod";

export const appRouter = router({
  system: systemRouter,

  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // ============= Conversations Router =============
  conversations: router({
    list: protectedProcedure.query(({ ctx }) =>
      getUserConversations(ctx.user.id)
    ),

    create: protectedProcedure
      .input(
        z.object({
          title: z.string().optional(),
          description: z.string().optional(),
          model: z.string().optional(),
          temperature: z.number().int().min(0).max(10).optional(),
          maxTokens: z.number().int().positive().optional(),
          systemPrompt: z.string().optional(),
        })
      )
      .mutation(({ ctx, input }) =>
        createConversation(ctx.user.id, {
          title: input.title || `Conversa ${new Date().toLocaleDateString('pt-BR')}`,
          description: input.description,
          model: input.model,
          temperature: input.temperature,
          maxTokens: input.maxTokens,
          systemPrompt: input.systemPrompt,
        })
      ),

    get: protectedProcedure
      .input(z.object({ id: z.string() }))
      .query(async ({ ctx, input }) => {
        const conversation = await getConversation(input.id);
        if (!conversation || conversation.userId !== ctx.user.id) {
          throw new Error("Conversa não encontrada");
        }
        return conversation;
      }),

    update: protectedProcedure
      .input(
        z.object({
          id: z.string(),
          title: z.string().optional(),
          description: z.string().optional(),
          model: z.string().optional(),
          temperature: z.number().int().min(0).max(10).optional(),
          maxTokens: z.number().int().positive().optional(),
          systemPrompt: z.string().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        const conversation = await getConversation(input.id);
        if (!conversation || conversation.userId !== ctx.user.id) {
          throw new Error("Conversa não encontrada");
        }

        return updateConversation(input.id, {
          title: input.title,
          description: input.description,
          model: input.model,
          temperature: input.temperature,
          maxTokens: input.maxTokens,
          systemPrompt: input.systemPrompt,
        });
      }),

    delete: protectedProcedure
      .input(z.object({ id: z.string() }))
      .mutation(async ({ ctx, input }) => {
        const conversation = await getConversation(input.id);
        if (!conversation || conversation.userId !== ctx.user.id) {
          throw new Error("Conversa não encontrada");
        }

        await deleteConversation(input.id);
        return { success: true };
      }),
  }),

  // ============= Messages Router =============
  messages: router({
    list: protectedProcedure
      .input(z.object({ conversationId: z.string() }))
      .query(async ({ ctx, input }) => {
        const conversation = await getConversation(input.conversationId);
        if (!conversation || conversation.userId !== ctx.user.id) {
          throw new Error("Conversa não encontrada");
        }

        return getConversationMessages(input.conversationId);
      }),

    send: protectedProcedure
      .input(
        z.object({
          conversationId: z.string(),
          content: z.string(),
          toolCalls: z.string().optional(),
          toolResults: z.string().optional(),
          metadata: z.string().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        const conversation = await getConversation(input.conversationId);
        if (!conversation || conversation.userId !== ctx.user.id) {
          throw new Error("Conversa não encontrada");
        }

        // Create user message
        const userMessage = await createMessage(input.conversationId, {
          role: "user",
          content: input.content,
          toolCalls: input.toolCalls,
          toolResults: input.toolResults,
          metadata: input.metadata,
        });

        // Process with OpenManus agent (mock response for now)
        let assistantContent = "Resposta do agente OpenManus";
        try {
          assistantContent = `Echo: ${input.content}\n\nEsta é uma resposta de demonstração. A integração completa com o agente OpenManus será implementada em breve.`;
        } catch (error) {
          console.error("Erro ao processar com OpenManus:", error);
          assistantContent = "Erro ao processar sua mensagem com o agente OpenManus.";
        }

        const assistantMessage = await createMessage(input.conversationId, {
          role: "assistant",
          content: assistantContent,
          metadata: JSON.stringify({ source: "openmanus-agent" }),
        });

        return {
          userMessage,
          assistantMessage,
        };
      }),

    get: protectedProcedure
      .input(z.object({ id: z.string() }))
      .query(async ({ ctx, input }) => {
        const message = await getMessage(input.id);
        if (!message) {
          throw new Error("Mensagem não encontrada");
        }

        // Verify user owns this message's conversation
        const conversation = await getConversation(message.conversationId);
        if (!conversation || conversation.userId !== ctx.user.id) {
          throw new Error("Acesso negado");
        }

        return message;
      }),
  }),

  // ============= Tools Router =============
  tools: router({
    list: protectedProcedure.query(() => getTools()),

    get: protectedProcedure
      .input(z.object({ id: z.string() }))
      .query(({ input }) => {
        return null;
      }),
  }),

  // ============= User Preferences Router =============
  preferences: router({
    get: protectedProcedure.query(({ ctx }) =>
      getUserPreferences(ctx.user.id)
    ),

    update: protectedProcedure
      .input(
        z.object({
          theme: z.string().optional(),
          language: z.string().optional(),
          defaultModel: z.string().optional(),
          defaultTemperature: z.number().int().min(0).max(10).optional(),
          defaultMaxTokens: z.number().int().positive().optional(),
          enabledTools: z.string().optional(),
        })
      )
      .mutation(({ ctx, input }) =>
        upsertUserPreferences(ctx.user.id, {
          theme: input.theme,
          language: input.language,
          defaultModel: input.defaultModel,
          defaultTemperature: input.defaultTemperature,
          defaultMaxTokens: input.defaultMaxTokens,
          enabledTools: input.enabledTools,
        })
      ),
  }),
});

export type AppRouter = typeof appRouter;
