# OpenManus Web UI - TODO

## Funcionalidades Principais

### Interface de Chat
- [x] Layout principal com sidebar e área de chat
- [x] Componente de entrada de mensagens
- [x] Histórico de conversas
- [x] Tema escuro estilo Grok
- [ ] Suporte a markdown nas mensagens
- [ ] Suporte a anexos de arquivos
- [ ] Indicador de digitação do agente

### Integração com OpenManus
- [ ] Integrar agente Manus com a interface
- [ ] Suporte a chamadas de ferramentas (tools)
- [ ] Suporte a execução de código Python
- [ ] Suporte a navegação web com browser
- [ ] Suporte a análise de dados
- [ ] Suporte a MCP (Model Context Protocol)

### Gerenciamento de Conversas
- [x] Criar nova conversa
- [x] Listar conversas do usuário
- [x] Carregar conversa existente
- [x] Atualizar título da conversa
- [ ] Deletar conversa
- [ ] Arquivar conversa
- [ ] Buscar em conversas

### Configurações e Preferências
- [ ] Página de configurações
- [ ] Seleção de modelo de IA
- [ ] Ajuste de temperatura
- [ ] Ajuste de max tokens
- [ ] Seleção de ferramentas ativas
- [ ] Tema (claro/escuro)
- [ ] Idioma

### Autenticação e Segurança
- [x] Sistema de login com Manus OAuth
- [x] Sistema de logout
- [ ] Gerenciamento de sessão
- [ ] Proteção de rotas

### Banco de Dados
- [x] Schema de conversas
- [x] Schema de mensagens
- [x] Schema de ferramentas
- [x] Schema de preferências do usuário
- [x] Migrações aplicadas

### Testes
- [x] Testes unitários para routers tRPC
- [ ] Testes de integração com OpenManus
- [ ] Testes de UI com Vitest
- [ ] Testes de autenticação

### Documentação
- [ ] README com instruções de instalação
- [ ] Documentação da API tRPC
- [ ] Guia de uso da interface
- [ ] Guia de integração com OpenManus

### Deploy
- [ ] Configurar variáveis de ambiente
- [ ] Preparar para produção
- [ ] Criar checkpoint final
- [ ] Publicar projeto
