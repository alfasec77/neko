import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { APP_LOGO, APP_TITLE, getLoginUrl } from "@/const";
import { trpc } from "@/lib/trpc";
import { useEffect, useState, useRef } from "react";
import { Loader2, Send, Plus, Menu, Settings, LogOut } from "lucide-react";

interface Message {
  id: string;
  role: "user" | "assistant" | "system";
  content: string;
  createdAt: string | Date | null;
}

interface Conversation {
  id: string;
  title: string;
  description?: string | null;
  model: string;
  temperature: number;
  maxTokens: number;
  createdAt: string | Date;
  updatedAt: string | Date;
}

export default function Home() {
  const { user, loading: authLoading, isAuthenticated, logout } = useAuth();
  const [currentConversationId, setCurrentConversationId] = useState<string | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputValue, setInputValue] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // tRPC queries and mutations
  const conversationsQuery = trpc.conversations.list.useQuery(undefined, {
    enabled: isAuthenticated,
  });

  const messagesQuery = trpc.messages.list.useQuery(
    { conversationId: currentConversationId || "" },
    { enabled: !!currentConversationId && isAuthenticated }
  );

  const createConversationMutation = trpc.conversations.create.useMutation();
  const sendMessageMutation = trpc.messages.send.useMutation();

  // Update conversations when query data changes
  useEffect(() => {
    if (conversationsQuery.data) {
      setConversations(conversationsQuery.data as Conversation[]);
    }
  }, [conversationsQuery.data]);

  // Update messages when query data changes
  useEffect(() => {
    if (messagesQuery.data) {
      setMessages(
        messagesQuery.data.map((msg: any) => ({
          ...msg,
          createdAt: msg.createdAt || new Date(),
        }))
      );
    }
  }, [messagesQuery.data]);

  // Auto-scroll to bottom when new messages arrive
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleNewConversation = async () => {
    try {
      const result = await createConversationMutation.mutateAsync({
        title: `Conversa ${new Date().toLocaleDateString("pt-BR")}`,
      });
      setCurrentConversationId(result.id);
      setMessages([]);
      setInputValue("");
    } catch (error) {
      console.error("Erro ao criar conversa:", error);
    }
  };

  const handleSendMessage = async () => {
    if (!inputValue.trim() || !currentConversationId || isLoading) return;

    const userMessage = inputValue;
    setInputValue("");
    setIsLoading(true);

    try {
      const result = await sendMessageMutation.mutateAsync({
        conversationId: currentConversationId,
        content: userMessage,
      });

      // Add messages to the UI
      setMessages((prev) => [
        ...prev,
        {
          id: result.userMessage.id,
          role: "user",
          content: userMessage,
          createdAt: result.userMessage.createdAt || new Date(),
        },
        {
          id: result.assistantMessage.id,
          role: "assistant",
          content: result.assistantMessage.content,
          createdAt: result.assistantMessage.createdAt || new Date(),
        },
      ]);
    } catch (error) {
      console.error("Erro ao enviar mensagem:", error);
      setInputValue(userMessage);
    } finally {
      setIsLoading(false);
    }
  };

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-900 to-slate-800">
        <Loader2 className="w-8 h-8 animate-spin text-blue-500" />
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-br from-slate-900 to-slate-800 text-white p-4">
        <div className="text-center max-w-md">
          {APP_LOGO && <img src={APP_LOGO as string} alt="Logo" className="w-16 h-16 mx-auto mb-6" />}
          <h1 className="text-4xl font-bold mb-2">{APP_TITLE || "OpenManus"}</h1>
          <p className="text-gray-400 mb-8">
            Interface inteligente para agentes autônomos com capacidades avançadas de IA
          </p>
          <Button
            onClick={() => (window.location.href = getLoginUrl())}
            className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-3 rounded-lg font-semibold"
          >
            Entrar com Manus
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex bg-slate-900 text-white">
      {/* Sidebar */}
      <div
        className={`${
          sidebarOpen ? "w-64" : "w-0"
        } bg-slate-800 border-r border-slate-700 transition-all duration-300 overflow-hidden flex flex-col`}
      >
        <div className="p-4 border-b border-slate-700">
          <Button
            onClick={handleNewConversation}
            className="w-full bg-blue-600 hover:bg-blue-700 text-white flex items-center justify-center gap-2"
            disabled={createConversationMutation.isPending}
          >
            <Plus className="w-4 h-4" />
            Nova Conversa
          </Button>
        </div>

        <div className="flex-1 overflow-y-auto p-4 space-y-2">
          {conversations.map((conv) => (
            <button
              key={conv.id}
              onClick={() => {
                setCurrentConversationId(conv.id);
                setMessages([]);
              }}
              className={`w-full text-left p-3 rounded-lg transition-colors ${
                currentConversationId === conv.id
                  ? "bg-blue-600 text-white"
                  : "bg-slate-700 hover:bg-slate-600 text-gray-200"
              }`}
            >
              <div className="font-semibold truncate">{conv.title}</div>
              <div className="text-xs text-gray-400 truncate">
                {typeof conv.updatedAt === "string"
                  ? new Date(conv.updatedAt).toLocaleDateString("pt-BR")
                  : conv.updatedAt instanceof Date
                  ? conv.updatedAt.toLocaleDateString("pt-BR")
                  : ""}
              </div>
            </button>
          ))}
        </div>

        <div className="border-t border-slate-700 p-4 space-y-2">
          <Button
            variant="ghost"
            className="w-full justify-start text-gray-300 hover:text-white hover:bg-slate-700"
          >
            <Settings className="w-4 h-4 mr-2" />
            Configurações
          </Button>
          <Button
            variant="ghost"
            className="w-full justify-start text-gray-300 hover:text-white hover:bg-slate-700"
            onClick={() => logout()}
          >
            <LogOut className="w-4 h-4 mr-2" />
            Sair
          </Button>
        </div>
      </div>

      {/* Main Chat Area */}
      <div className="flex-1 flex flex-col">
        {/* Header */}
        <div className="border-b border-slate-700 bg-slate-800 p-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setSidebarOpen(!sidebarOpen)}
              className="text-gray-400 hover:text-white"
            >
              <Menu className="w-5 h-5" />
            </Button>
            <div>
              <h1 className="text-xl font-bold">{APP_TITLE || "OpenManus"}</h1>
              <p className="text-sm text-gray-400">Agente de IA Autônomo</p>
            </div>
          </div>
          <div className="text-sm text-gray-400">
            {user?.name || "Usuário"}
          </div>
        </div>

        {/* Messages Area */}
        <div className="flex-1 overflow-y-auto p-6 space-y-4">
          {!currentConversationId ? (
            <div className="h-full flex items-center justify-center">
              <div className="text-center">
                <h2 className="text-2xl font-bold mb-4">Bem-vindo ao OpenManus</h2>
                <p className="text-gray-400 mb-8">
                  Selecione uma conversa ou crie uma nova para começar
                </p>
                <Button
                  onClick={handleNewConversation}
                  className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2"
                  disabled={createConversationMutation.isPending}
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Iniciar Conversa
                </Button>
              </div>
            </div>
          ) : (
            <>
              {messages.length === 0 ? (
                <div className="h-full flex items-center justify-center">
                  <div className="text-center">
                    <p className="text-gray-400">Nenhuma mensagem ainda. Comece a conversar!</p>
                  </div>
                </div>
              ) : (
                messages.map((msg) => (
                  <div
                    key={msg.id}
                    className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}
                  >
                    <div
                      className={`max-w-2xl px-4 py-3 rounded-lg ${
                        msg.role === "user"
                          ? "bg-blue-600 text-white"
                          : "bg-slate-700 text-gray-100"
                      }`}
                    >
                      <p className="whitespace-pre-wrap">{msg.content}</p>
                      <p className="text-xs mt-2 opacity-70">
                        {typeof msg.createdAt === "string"
                          ? new Date(msg.createdAt).toLocaleTimeString("pt-BR")
                          : msg.createdAt instanceof Date
                          ? msg.createdAt.toLocaleTimeString("pt-BR")
                          : ""}
                      </p>
                    </div>
                  </div>
                ))
              )}
              {isLoading && (
                <div className="flex justify-start">
                  <div className="bg-slate-700 text-gray-100 px-4 py-3 rounded-lg flex items-center gap-2">
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>Processando...</span>
                  </div>
                </div>
              )}
              <div ref={messagesEndRef} />
            </>
          )}
        </div>

        {/* Input Area */}
        {currentConversationId && (
          <div className="border-t border-slate-700 bg-slate-800 p-4">
            <div className="flex gap-3">
              <Input
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                onKeyPress={(e) => {
                  if (e.key === "Enter" && !e.shiftKey) {
                    e.preventDefault();
                    handleSendMessage();
                  }
                }}
                placeholder="Digite sua mensagem aqui... (Shift+Enter para nova linha)"
                className="flex-1 bg-slate-700 border-slate-600 text-white placeholder-gray-400"
                disabled={isLoading}
              />
              <Button
                onClick={handleSendMessage}
                disabled={isLoading || !inputValue.trim()}
                className="bg-blue-600 hover:bg-blue-700 text-white px-6"
              >
                {isLoading ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <Send className="w-4 h-4" />
                )}
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
